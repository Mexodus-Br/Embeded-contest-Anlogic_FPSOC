cd D:/Works/Embedded_contest/dev/pl_safety/optimization/timing_20261017/baseline_cdc1
import_device dr1_90.db -package DR1M90GEG400 -speed 2
set_param flow thread 16
get_num_thread
import_db D:/Works/Embedded_contest/dev/pl_safety/build/predecode_top7/route.db
set_param flow thread 16
puts "TIMING_OPT_THREADS [get_param flow thread]"
get_num_thread
read_adc -file D:/Works/Embedded_contest/dev/pl_safety/build/predecode_top7/gp/gp.adc
read_sdc D:/Works/Embedded_contest/dev/pl_safety/build/predecode_top7/gp/gp.sdc
read_sdc D:/Works/Embedded_contest/dev/pl_safety/build/predecode_top7/gp/ps-generated-properties.tcl
update_timing -mode final
set first {}
set second {}
foreach r [get_regs -hier -quiet *inputs*] {
 if {[string match {*motion/inputs/meta*} $r]} {lappend first $r}
 if {[string match {*motion/inputs/sync*} $r]} {lappend second $r}
}
puts "CDC_FIRST [llength $first] $first"
puts "CDC_SECOND [llength $second] $second"
if {[llength $first]!=4 || [llength $second]!=4} {error "Expected four meta and four sync registers"}
report_timing_path -from $first -to $second -path_num 10 -file meta_to_sync.timing
report_timing_exception -path_num 4 -file exceptions.timing
report_nets [get_nets -hier -quiet *inputs/meta*] -connection -pin_display_limit 32
report_nets [get_nets -hier -quiet *inputs/contact_n*] -connection -pin_display_limit 32
set cells [get_cells -hier -quiet *inputs/meta_reg*]
puts "CDC_META_CELLS [llength $cells] $cells"
foreach c $cells {report_cells [list $c] -connection -attributes;report_property $c}
set cells [get_cells -hier -quiet *inputs/sync_reg*]
puts "CDC_SYNC_CELLS [llength $cells] $cells"
foreach c $cells {report_cells [list $c] -connection -attributes;report_property $c}
check_timing -verbose -file replay.check
report_timing_summary -path_num 1 -file replay.timing
puts TIMING_OPT_CDC_COMPLETE
exit
