cd D:/Works/Embedded_contest/dev/pl_safety/optimization/timing_20261017/final_cdc1
import_device dr1_90.db -package DR1M90GEG400 -speed 2
set_param flow thread 16
get_num_thread
import_db D:/Works/Embedded_contest/dev/pl_safety/build/closure_cofactor_route5/route.db
set_param flow thread 16
puts "TIMING_OPT_THREADS [get_param flow thread]"
get_num_thread
clear_user_sdc
read_adc -file D:/Works/Embedded_contest/dev/pl_safety/build/closure_cofactor_route5/gp/gp.adc
read_sdc D:/Works/Embedded_contest/dev/pl_safety/build/closure_cofactor_route5/gp/gp.sdc
read_sdc D:/Works/Embedded_contest/dev/pl_safety/build/closure_cofactor_route5/gp/ps-generated-properties.tcl
update_timing -mode final
set first {}
set second {}
foreach r [get_regs -hier -quiet *inputs*] {
 if {[string match {*motion/inputs/meta*} $r]} {lappend first $r}
 if {[string match {*motion/inputs/sync*} $r]} {lappend second $r}
}
puts "CDC_FIRST [llength $first] $first"
puts "CDC_SECOND [llength $second] $second"
if {[llength $first]!=4 || [llength $second]!=4} {error "Expected four meta and four sync registers"}
report_timing_path -from $first -to $second -path_num 10 -file meta_to_sync.timing
# Logical meta/sync may share a Slice named after unrelated logic. Derive
# every actual source/destination cell from the timed paths, not its name.
set fd [open meta_to_sync.timing r]
set contents [read $fd]
close $fd
set physical {}
foreach line [split $contents [format %c 10]] {
 if {[regexp {^(Begin Point|End Point)\s*:\s*(\S+)} $line unused kind pin]} {
  set cell [string range $pin 0 [expr {[string last . $pin]-1}]]
  if {[lsearch -exact $physical $cell]<0} {lappend physical $cell}
 }
}
puts "CDC_PHYSICAL_CHAIN_CELLS [llength $physical] $physical"
if {[llength $physical]<4 || [llength $physical]>8} {error "Unexpected physical synchronizer cell coverage"}
foreach cell $physical {
 set one [get_cells -quiet $cell]
 if {[llength $one]!=1} {error "Missing exact physical synchronizer cell"}
 report_cells $one -connection -attributes
 report_property [lindex $one 0]
}
report_timing_exception -path_num 4 -file exceptions.timing
report_nets [get_nets -hier -quiet *inputs/meta*] -connection -pin_display_limit 32
report_nets [get_nets -hier -quiet *inputs/contact_n*] -connection -pin_display_limit 32
set cells [get_cells -hier -quiet *inputs/meta_reg*]
puts "CDC_META_CELLS [llength $cells] $cells"
foreach c $cells {report_cells [list $c] -connection -attributes;report_property $c}
set cells [get_cells -hier -quiet *inputs/sync_reg*]
puts "CDC_SYNC_CELLS [llength $cells] $cells"
foreach c $cells {report_cells [list $c] -connection -attributes;report_property $c}
check_timing -verbose -file replay.check
report_timing_summary -path_num 1 -file replay.timing
puts TIMING_OPT_CDC_COMPLETE
exit
