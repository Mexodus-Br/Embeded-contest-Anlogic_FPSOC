cd D:/Works/Embedded_contest/dev/pl_safety/optimization/timing_20261017/baseline_nets1
import_device dr1_90.db -package DR1M90GEG400 -speed 2
set_param flow thread 16
get_num_thread
import_db D:/Works/Embedded_contest/dev/pl_safety/build/predecode_top7/route.db
set_param flow thread 16
if {[get_param flow thread]!=16} {error "Expected threads16"}
puts "TIMING_OPT_THREADS [get_param flow thread]"
get_num_thread
set f [open nets.tsv w]
puts $f "name	flat_pins	drivers	clock"
foreach n [get_nets -hier -quiet *] {
 puts $f "$n	[get_property FLAT_CELL_PIN_COUNT $n]	[get_property DRIVER_COUNT $n]	[get_property CLOCK $n]"
}
close $f
set f [open high_net_pins.tsv w]
foreach n [get_nets -hier -quiet -filter {FLAT_CELL_PIN_COUNT > 65} *] {
 puts $f "$n	[join [get_pins -hier -quiet -of [list $n]] ,]"
 report_nets [list $n] -connection -pin_display_limit 12
}
close $f
read_sdc D:/Works/Embedded_contest/dev/pl_safety/build/predecode_top7/gp/gp.sdc
read_sdc D:/Works/Embedded_contest/dev/pl_safety/build/predecode_top7/gp/ps-generated-properties.tcl
update_timing -mode final
report_timing_summary -path_num 10 -file replay.timing
report_timing_path -from [get_regs -hier -quiet *pulse_event*] -path_num 10 -file pulse_event.timing
report_cells [get_cells {control/core/fabric/dma_core/motion/motion/kernel/executor/pulse_event_reg[1]_syn_2}] -connection -attributes
check_timing -verbose -file replay.check
puts TIMING_OPT_PHYSICAL_COMPLETE
exit
