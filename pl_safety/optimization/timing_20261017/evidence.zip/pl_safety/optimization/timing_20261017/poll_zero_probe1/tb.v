`timescale 1ns/1ps
module tb;parameter [31:0] P=5;
reg clk=0;
reg rst_n=0;
reg [63:0] time_us=0;
reg rx=0;
reg request_valid=0;
reg [7:0] request_address=0;
reg [2:0] request_query=0;
reg [31:0] request_sequence=0;
wire request_ready;
wire tx;
wire de;
wire active;
wire done;
wire [7:0] result;
wire bus_blocked;
wire push;
wire [255:0] push_data;
wire [31:0] accepted;
wire [31:0] errors;
wire [31:0] ignored_rx;
rs485_transaction #(.CLK_HZ(100),.BAUD(10),.POLL_CYCLES(P),.TIMEOUT_CYCLES(240),.INTERBYTE_CYCLES(30),.RETRIES(1),.PRE_CYCLES(2),.POST_CYCLES(2),.TURN_CYCLES(2),.NORMAL_CYCLES(20),.ERROR_CYCLES(30)) dut(.clk(clk),.rst_n(rst_n),.time_us(time_us),.rx(rx),.request_valid(request_valid),.request_address(request_address),.request_query(request_query),.request_sequence(request_sequence),.request_ready(request_ready),.tx(tx),.de(de),.active(active),.done(done),.result(result),.bus_blocked(bus_blocked),.push(push),.push_data(push_data),.accepted(accepted),.errors(errors),.ignored_rx(ignored_rx));
wire request_ready_ref;
wire tx_ref;
wire de_ref;
wire active_ref;
wire done_ref;
wire [7:0] result_ref;
wire bus_blocked_ref;
wire push_ref;
wire [255:0] push_data_ref;
wire [31:0] accepted_ref;
wire [31:0] errors_ref;
wire [31:0] ignored_rx_ref;
reference_transaction #(.CLK_HZ(100),.BAUD(10),.POLL_CYCLES(P),.TIMEOUT_CYCLES(240),.INTERBYTE_CYCLES(30),.RETRIES(1),.PRE_CYCLES(2),.POST_CYCLES(2),.TURN_CYCLES(2),.NORMAL_CYCLES(20),.ERROR_CYCLES(30)) reference(.clk(clk),.rst_n(rst_n),.time_us(time_us),.rx(rx),.request_valid(request_valid),.request_address(request_address),.request_query(request_query),.request_sequence(request_sequence),.request_ready(request_ready_ref),.tx(tx_ref),.de(de_ref),.active(active_ref),.done(done_ref),.result(result_ref),.bus_blocked(bus_blocked_ref),.push(push_ref),.push_data(push_data_ref),.accepted(accepted_ref),.errors(errors_ref),.ignored_rx(ignored_rx_ref));
always #5 clk=~clk;
 integer i,j,seed=32'h501720,checks=0;reg [31:0] injected;
 always @(posedge clk)begin #1;if(rst_n)begin
  checks=checks+1;
  if({request_ready,tx,de,active,done,result,bus_blocked,push,push_data,accepted,errors,ignored_rx} !== {request_ready_ref,tx_ref,de_ref,active_ref,done_ref,result_ref,bus_blocked_ref,push_ref,push_data_ref,accepted_ref,errors_ref,ignored_rx_ref})$fatal(1,"transaction public outputs differ");
  if(dut.poll_zero !== (dut.poll_timer==0))$fatal(1,"current timer predicate invariant");
 end end
 initial begin
 #2;rst_n=0;rx=1;#10;rst_n=1;
 for(i=0;i<40000;i=i+1)begin
  @(negedge clk);time_us=time_us+1;request_valid=$random(seed)&1;
  request_address=1+($random(seed)&3);request_query=$random(seed)%5;request_sequence=request_sequence+1;
  rx=(i%1000<700)?1:($random(seed)&1);
  if(i%257==0)begin
   case((i/257)%7)
    0:injected=0;1:injected=1;2:injected=2;3:injected=32'hffffffff;
    4:injected=32'h80000000;5:injected=P;default:injected=P-1;
   endcase
   dut.poll_timer=injected;reference.poll_timer=injected;dut.poll_zero=injected==0;
  end
  if(i%5003==0)rst_n=0;else rst_n=1;
 end
 @(negedge clk);$display("PASS transaction differential checks=%0d poll=%h",checks,P);$finish;
 end
 endmodule
