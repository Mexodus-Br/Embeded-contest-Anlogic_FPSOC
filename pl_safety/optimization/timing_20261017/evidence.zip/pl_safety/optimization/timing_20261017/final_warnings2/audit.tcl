cd D:/Works/Embedded_contest/dev/pl_safety/optimization/timing_20261017/final_warnings2
import_device dr1_90.db -package DR1M90GEG400 -speed 2
set_param flow thread 16
get_num_thread
import_db D:/Works/Embedded_contest/dev/pl_safety/build/closure_cofactor_route5/route.db
set_param flow thread 16
get_num_thread
set all [get_nets -hier -quiet *]
foreach name {{control/core/fabric/rs485/collector/state_reg[4]_syn_14} {control/core/fabric/rs485/collector/state_reg[4]_syn_15} {control/core/fabric/rs485/collector/state_reg[4]_syn_16} {control/core/fabric/rs485/collector/state_reg[4]_syn_17}} {
 set pos [lsearch -exact $all $name]
 if {$pos<0} {puts "WARNING_NET $name ABSENT"} else {
  set n [list [lindex $all $pos]]
  puts "WARNING_NET_BEGIN $name"
  report_nets $n -connection -pin_display_limit 10000
  puts "WARNING_NET_END $name"
 }
}
puts WARNING_NET_AUDIT_COMPLETE
exit
