set_param flow thread 16
get_num_thread
puts "COMMANDS *sdc* [info commands *sdc*]"
puts "COMMANDS *constraint* [info commands *constraint*]"
puts "COMMANDS *uncertainty* [info commands *uncertainty*]"
puts "COMMANDS *reset* [info commands *reset*]"
puts "COMMANDS *clear* [info commands *clear*]"
puts "COMMANDS *remove* [info commands *remove*]"
catch {help read_sdc} msg
puts "HELP read_sdc $msg"
catch {help remove_clock_uncertainty} msg
puts "HELP remove_clock_uncertainty $msg"
catch {help reset_sdc} msg
puts "HELP reset_sdc $msg"
catch {help reset_timing} msg
puts "HELP reset_timing $msg"
exit
