cd D:/Works/Embedded_contest/dev/pl_safety/optimization/timing_20261017/joint_path_audit1
import_device dr1_90.db -package DR1M90GEG400 -speed 2
set_param flow thread 16
get_num_thread
import_db D:/Works/Embedded_contest/dev/pl_safety/build/closure_joint_top2/route.db
set_param flow thread 16
get_num_thread
report_cells [get_cells {control/core/fabric/dma_core/dma/voxztl/eqlled$lkjjvr/gkclky/afwqjs_n1_syn_21}] -connection -attributes
report_cells [get_cells {control/core/fabric/dma_core/motion/motion/kernel/planner/mux73_syn_1655}] -connection -attributes
report_cells [get_cells {control/core/fabric/dma_core/motion/motion/kernel/planner/mux73_syn_1894}] -connection -attributes
report_cells [get_cells {control/core/fabric/dma_core/motion/motion/kernel/executor/dir_age[0]_b[127]_syn_204}] -connection -attributes
report_cells [get_cells {control/core/fabric/dma_core/motion/motion/kernel/executor/mux88_syn_50}] -connection -attributes
puts JOINT_PATH_CONNECTIONS_COMPLETE
exit
