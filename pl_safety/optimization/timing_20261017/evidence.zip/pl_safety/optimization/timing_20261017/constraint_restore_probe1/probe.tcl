cd D:/Works/Embedded_contest/dev/pl_safety/optimization/timing_20261017/constraint_restore_probe1
import_device dr1_90.db -package DR1M90GEG400 -speed 2
set_param flow thread 16
get_num_thread
import_db D:/Works/Embedded_contest/dev/pl_safety/build/closure_joint_route3/route.db
set_param flow thread 16
get_num_thread
export_sdc -file before.sdc
update_timing -mode final
report_timing_summary -path_num 1 -file before.timing
clear_user_sdc
read_sdc D:/Works/Embedded_contest/dev/pl_safety/build/closure_joint_route3/gp/gp.sdc
read_sdc D:/Works/Embedded_contest/dev/pl_safety/build/closure_joint_route3/gp/ps-generated-properties.tcl
update_timing -mode final
report_timing_summary -path_num 1 -file restored.timing
export_sdc -file restored.sdc
check_timing -verbose -file restored.check
puts CONSTRAINT_RESTORE_PROBE_COMPLETE
exit
