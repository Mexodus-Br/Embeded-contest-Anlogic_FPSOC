cd D:/Works/Embedded_contest/dev/pl_safety/optimization/timing_20261017/baseline_physical
import_device dr1_90.db -package DR1M90GEG400 -speed 2
set_param flow thread 16
get_num_thread
import_db D:/Works/Embedded_contest/dev/pl_safety/build/predecode_top7/route.db
set_param flow thread 16
if {[get_param flow thread]!=16} {error "threads mismatch"}
puts "TIMING_OPT_THREADS [get_param flow thread]"
get_num_thread
report_route_status -fanout_stat -file fanout.rpt
set ns [get_nets -hier -quiet *]
puts "NET_COUNT [llength $ns]"
report_property [lindex $ns 0]
report_cells [get_cells {control/core/fabric/dma_core/motion/motion/core/kernel/executor/pulse_event_reg[1]_syn_2}] -connection -attributes
puts TIMING_OPT_BASELINE_PHYSICAL_COMPLETE
exit
