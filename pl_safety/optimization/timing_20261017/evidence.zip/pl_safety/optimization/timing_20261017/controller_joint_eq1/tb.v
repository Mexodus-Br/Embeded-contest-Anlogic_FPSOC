`timescale 1ns/1ps
module tb;parameter [63:0] T=5;
reg clk=0;
reg rst_n=0;
reg [63:0] time_us=0;
reg qualified=0;
reg [3:0] active=0;
reg [3:0] released=0;
reg home_request=0;
reg clear_request=0;
reg stop_request=0;
reg idle=0;
reg pulse_safe=0;
reg external_abort=0;
reg [2:0] executor_fault=0;
reg [3:0] position_valid=0;
reg [3:0] pulse_event=0;
reg [3:0] config_valid=0;
wire config_ok;
wire normal_inhibit;
wire home_owner;
wire home_enable;
wire home_reference;
wire home_complete;
wire [2:0] home_run;
wire [2:0] home_direction;
wire [191:0] home_period;
wire [191:0] home_reference_position;
wire stop_motion;
wire disable_motion;
wire [3:0] invalidate;
wire clear_executor;
wire [3:0] state;
wire [31:0] causes;
wire [31:0] first_cause;
wire [63:0] first_time;
wire [63:0] event_sequence;
wire [63:0] home_start_time;
wire [63:0] home_done_time;
wire [2:0] hit_mask;
wire [2:0] released_mask;
wire [2:0] done_mask;
wire [191:0] travel;
wire accepted;
wire rejected;
wire home_done;
wire home_cancelled;
wire request_ok;
wire clear_ok;
safety_controller #(.CONFIG_APPROVED(1),.SEARCH_PERIOD({3{64'd20}}),.PULL_PERIOD({3{64'd20}}),.PRE_PERIOD({3{64'd20}}),.SEARCH_MAX_STEPS({3{T}}),.PULL_MAX_STEPS({3{T}}),.PRE_MAX_STEPS({3{T}}),.PRE_DISTANCE({3{T}}),.PULL_DISTANCE({3{T}}),.SEARCH_MAX_US(64'd10000),.PULL_MAX_US(64'd10000),.PRE_MAX_US(64'd10000)) dut(.clk(clk),.rst_n(rst_n),.time_us(time_us),.qualified(qualified),.active(active),.released(released),.home_request(home_request),.clear_request(clear_request),.stop_request(stop_request),.idle(idle),.pulse_safe(pulse_safe),.external_abort(external_abort),.executor_fault(executor_fault),.position_valid(position_valid),.pulse_event(pulse_event),.config_valid(config_valid),.config_ok(config_ok),.normal_inhibit(normal_inhibit),.home_owner(home_owner),.home_enable(home_enable),.home_reference(home_reference),.home_complete(home_complete),.home_run(home_run),.home_direction(home_direction),.home_period(home_period),.home_reference_position(home_reference_position),.stop_motion(stop_motion),.disable_motion(disable_motion),.invalidate(invalidate),.clear_executor(clear_executor),.state(state),.causes(causes),.first_cause(first_cause),.first_time(first_time),.event_sequence(event_sequence),.home_start_time(home_start_time),.home_done_time(home_done_time),.hit_mask(hit_mask),.released_mask(released_mask),.done_mask(done_mask),.travel(travel),.accepted(accepted),.rejected(rejected),.home_done(home_done),.home_cancelled(home_cancelled),.request_ok(request_ok),.clear_ok(clear_ok));
wire config_ok_ref;
wire normal_inhibit_ref;
wire home_owner_ref;
wire home_enable_ref;
wire home_reference_ref;
wire home_complete_ref;
wire [2:0] home_run_ref;
wire [2:0] home_direction_ref;
wire [191:0] home_period_ref;
wire [191:0] home_reference_position_ref;
wire stop_motion_ref;
wire disable_motion_ref;
wire [3:0] invalidate_ref;
wire clear_executor_ref;
wire [3:0] state_ref;
wire [31:0] causes_ref;
wire [31:0] first_cause_ref;
wire [63:0] first_time_ref;
wire [63:0] event_sequence_ref;
wire [63:0] home_start_time_ref;
wire [63:0] home_done_time_ref;
wire [2:0] hit_mask_ref;
wire [2:0] released_mask_ref;
wire [2:0] done_mask_ref;
wire [191:0] travel_ref;
wire accepted_ref;
wire rejected_ref;
wire home_done_ref;
wire home_cancelled_ref;
wire request_ok_ref;
wire clear_ok_ref;
reference_controller #(.CONFIG_APPROVED(1),.SEARCH_PERIOD({3{64'd20}}),.PULL_PERIOD({3{64'd20}}),.PRE_PERIOD({3{64'd20}}),.SEARCH_MAX_STEPS({3{T}}),.PULL_MAX_STEPS({3{T}}),.PRE_MAX_STEPS({3{T}}),.PRE_DISTANCE({3{T}}),.PULL_DISTANCE({3{T}}),.SEARCH_MAX_US(64'd10000),.PULL_MAX_US(64'd10000),.PRE_MAX_US(64'd10000)) reference(.clk(clk),.rst_n(rst_n),.time_us(time_us),.qualified(qualified),.active(active),.released(released),.home_request(home_request),.clear_request(clear_request),.stop_request(stop_request),.idle(idle),.pulse_safe(pulse_safe),.external_abort(external_abort),.executor_fault(executor_fault),.position_valid(position_valid),.pulse_event(pulse_event),.config_valid(config_valid),.config_ok(config_ok_ref),.normal_inhibit(normal_inhibit_ref),.home_owner(home_owner_ref),.home_enable(home_enable_ref),.home_reference(home_reference_ref),.home_complete(home_complete_ref),.home_run(home_run_ref),.home_direction(home_direction_ref),.home_period(home_period_ref),.home_reference_position(home_reference_position_ref),.stop_motion(stop_motion_ref),.disable_motion(disable_motion_ref),.invalidate(invalidate_ref),.clear_executor(clear_executor_ref),.state(state_ref),.causes(causes_ref),.first_cause(first_cause_ref),.first_time(first_time_ref),.event_sequence(event_sequence_ref),.home_start_time(home_start_time_ref),.home_done_time(home_done_time_ref),.hit_mask(hit_mask_ref),.released_mask(released_mask_ref),.done_mask(done_mask_ref),.travel(travel_ref),.accepted(accepted_ref),.rejected(rejected_ref),.home_done(home_done_ref),.home_cancelled(home_cancelled_ref),.request_ok(request_ok_ref),.clear_ok(clear_ok_ref));

 always #5 clk=~clk;
 integer checks=0,seed=32'h501710,cy=0,i,j,ph;
 reg [63:0] value;
 task verify;begin
 checks=checks+1;
 if({config_ok,normal_inhibit,home_owner,home_enable,home_reference,home_complete,home_run,home_direction,home_period,home_reference_position,stop_motion,disable_motion,invalidate,clear_executor,state,causes,first_cause,first_time,event_sequence,home_start_time,home_done_time,hit_mask,released_mask,done_mask,travel,accepted,rejected,home_done,home_cancelled,request_ok,clear_ok} !== {config_ok_ref,normal_inhibit_ref,home_owner_ref,home_enable_ref,home_reference_ref,home_complete_ref,home_run_ref,home_direction_ref,home_period_ref,home_reference_position_ref,stop_motion_ref,disable_motion_ref,invalidate_ref,clear_executor_ref,state_ref,causes_ref,first_cause_ref,first_time_ref,event_sequence_ref,home_start_time_ref,home_done_time_ref,hit_mask_ref,released_mask_ref,done_mask_ref,travel_ref,accepted_ref,rejected_ref,home_done_ref,home_cancelled_ref,request_ok_ref,clear_ok_ref})begin
  $display("cycle=%0d count=%h state=%d pulse=%b",cy,dut.count[0],state,pulse_event);
  $fatal(1,"controller all-output equivalence");
 end
 for(j=0;j<3;j=j+1)begin
  if(dut.search_at[j] !== (dut.count[j]>=T) || dut.search_before[j] !== (T!=0 && dut.count[j]==T-1) || dut.count_full[j] !== (&dut.count[j])) $fatal(1,"boundary invariant");
 end
 end endtask
 always @(posedge clk)begin cy=cy+1;#1;if(rst_n)verify;end
 always @(negedge clk)begin #2;if(rst_n)verify;end
 task set_count;input [63:0] v;integer k;begin
 for(k=0;k<3;k=k+1)begin
  dut.count[k]=v;reference.count[k]=v;
  dut.search_at[k]=v>=T;dut.search_before[k]=T!=0 && v==T-1;
  dut.pre_at[k]=v>=T;dut.pre_before[k]=T!=0 && v==T-1;
  dut.pull_at[k]=v>=T;dut.pull_before[k]=T!=0 && v==T-1;
  dut.count_full[k]=&v;
 end
 end endtask
 initial begin
 #2;rst_n=0;#10;rst_n=1;time_us=64'hfffffffffffffc18;qualified=1;released=15;idle=1;pulse_safe=1;config_valid=15;
 // Natural control/state transitions with random contacts, stops and pulses.
 for(i=0;i<16000;i=i+1)begin
  @(negedge clk);if(i%79==0 && i>1000)time_us={$random(seed),$random(seed)};else time_us=time_us+1;
  pulse_event=$random(seed)&7;active=(i%100<75)?0:($random(seed)&7);
  released=~active;home_request=i%100==1;clear_request=i%100==0;
  stop_request=i%293==0;external_abort=i%419==0;executor_fault=i%509==0;
  idle=i%5!=0;pulse_safe=i%3!=0;
 end
 // Inject mathematically consistent current state at unsigned carry/threshold
 // boundaries; subsequent updates/flags are entirely implementation-driven.
 for(ph=1;ph<=9;ph=ph+1)for(i=0;i<12;i=i+1)begin
  @(negedge clk);home_request=0;clear_request=0;stop_request=0;external_abort=0;executor_fault=0;
  active=0;released=0;idle=1;pulse_safe=0;time_us=0;
  dut.state=ph;reference.state=ph;dut.causes=0;reference.causes=0;
  dut.phase_time=0;reference.phase_time=0;dut.phase_deadline=10000;dut.phase_wrap=0;dut.pre_mask=7;reference.pre_mask=7;
  dut.hit_mask=0;reference.hit_mask=0;dut.released_mask=0;reference.released_mask=0;
  case(i)
   0:value=0;1:value=1;2:value=T-2;3:value=T-1;4:value=T;5:value=T+1;
   6:value=64'hfffffffffffffffd;7:value=64'hfffffffffffffffe;8:value=64'hffffffffffffffff;
   9:value=64'h7fffffffffffffff;10:value=64'h8000000000000000;default:value=64'hffffffff;
  endcase
  set_count(value);pulse_event=0;
  #1;verify;
  repeat(5)begin @(negedge clk);pulse_event=$random(seed)&7;end
 end
 @(negedge clk);rst_n=0;#11;rst_n=1;repeat(5)@(negedge clk);
 $display("PASS controller equivalence checks=%0d threshold=%h",checks,T);$finish;
 end
 endmodule
