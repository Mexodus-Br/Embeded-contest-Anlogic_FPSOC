cd D:/Works/Embedded_contest/dev/pl_safety/optimization/timing_20261017/net_probe1
import_device dr1_90.db -package DR1M90GEG400 -speed 2
set_param flow thread 16
get_num_thread
import_db D:/Works/Embedded_contest/dev/pl_safety/build/predecode_top7/route.db
set_param flow thread 16
get_num_thread
set n [get_nets -quiet al_1104]
puts "NET_HANDLE $n"
report_nets $n -connection -pin_display_limit 30
set pin [lindex [get_pins -hier -quiet *] 100]
puts "PIN_SAMPLE $pin"
report_property $pin
set n [get_nets -hier -quiet *control_rst_n_dup_101483]
puts "RESET_HANDLE $n"
report_nets $n -connection -pin_display_limit 8
puts NET_PROBE_COMPLETE
exit
