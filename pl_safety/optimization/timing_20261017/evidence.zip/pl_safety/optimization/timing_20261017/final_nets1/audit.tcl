cd D:/Works/Embedded_contest/dev/pl_safety/optimization/timing_20261017/final_nets1
import_device dr1_90.db -package DR1M90GEG400 -speed 2
set_param flow thread 16
get_num_thread
import_db D:/Works/Embedded_contest/dev/pl_safety/build/closure_cofactor_route5/route.db
set_param flow thread 16
if {[get_param flow thread]!=16} {error "Expected threads16"}
puts "TIMING_OPT_THREADS [get_param flow thread]"
get_num_thread
clear_user_sdc
read_sdc D:/Works/Embedded_contest/dev/pl_safety/build/closure_cofactor_route5/gp/gp.sdc
read_sdc D:/Works/Embedded_contest/dev/pl_safety/build/closure_cofactor_route5/gp/ps-generated-properties.tcl
set f [open nets.tsv w]
puts $f "name	flat_pins	drivers	clock"
foreach n [get_nets -hier -quiet *] {
 puts $f "$n	[get_property FLAT_CELL_PIN_COUNT $n]	[get_property DRIVER_COUNT $n]	[get_property CLOCK $n]"
}
close $f
# Full load classification is handled by pin_inventory.py using report_nets.
# This TD build does not implement get_pins -of net as a load-pin query.
update_timing -mode final
report_timing_summary -path_num 10 -file replay.timing
set pulses [get_regs -hier -quiet *pulse_event*]
puts "PULSE_REGISTER_SELECTION [llength $pulses] $pulses"
if {[llength $pulses]<3} {error "Missing three real axis pulse registers"}
report_timing_path -from $pulses -path_num 10 -file pulse_event.timing
set dir_ce {}
foreach axis {0 1 2} {
 set one [get_pins -hier -quiet *a${axis}_dir*.ce]
 if {[llength $one]!=1} {error "Expected exactly one real axis DIR CE"}
 lappend dir_ce [lindex $one 0]
 set data [get_pins -hier -quiet *a${axis}_dir*.doq*]
 if {[llength $data]<1} {error "Missing real DIR PAD data pins"}
 foreach pin $data {lappend dir_ce $pin}
}
puts "DIR_CE_SELECTION [llength $dir_ce] $dir_ce"
if {[llength $dir_ce]<6} {error "Expected CE and data coverage for all three actual DIR registers"}
report_timing_path -from $pulses -to $dir_ce -path_num 10 -file pulse_to_dir.timing
set fd [open pulse_event.timing r]
set content [read $fd]
close $fd
set physical {}
foreach line [split $content [format %c 10]] {
 if {[regexp {^Begin Point\s*:\s*(\S+)} $line unused pin]} {
  set cell [string range $pin 0 [expr {[string last . $pin]-1}]]
  if {[lsearch -exact $physical $cell]<0} {lappend physical $cell}
 }
}
if {[llength $physical]<1} {error "Missing timed physical pulse source"}
foreach cell $physical {
 set one [get_cells -quiet $cell]
 if {[llength $one]!=1} {error "Missing exact physical pulse source cell"}
 report_cells $one -connection -attributes
}
check_timing -verbose -file replay.check
puts TIMING_OPT_PHYSICAL_COMPLETE
exit
