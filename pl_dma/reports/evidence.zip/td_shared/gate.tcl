cd {D:/Works/Embedded_contest/dev/pl_dma/build/td_shared}
import_device dr1_90.db -package DR1M90GEG400 -speed 2
analyze -file {D:/Works/Embedded_contest/dev/pl_dma/build/ip/axi_dma.v}
analyze -file {D:/Works/Embedded_contest/dev/pl_dma/build/ip/axi_protocol_converter_merge.v}
analyze -file {D:/Works/Embedded_contest/dev/pl_dma/build/td_shared/axi_lite_two_way.v}
analyze -file {D:/Works/Embedded_contest/dev/pl_dma/build/td_shared/axis_loop_fifo.v}
analyze -file {D:/Works/Embedded_contest/dev/pl_dma/build/td_shared/dma_gp_full_top.v}
analyze -file {D:/Works/Embedded_contest/dev/pl_dma/build/td_shared/dma_gp_ps_top.v}
analyze -file {D:/Works/Embedded_contest/dev/pl_dma/build/td_shared/dma_lite_guard.v}
analyze -file {D:/Works/Embedded_contest/dev/pl_dma/build/td_shared/dma_loopback_top.v}
analyze -file {D:/Works/Embedded_contest/dev/pl_dma/build/td_shared/dma_shared_lite_top.v}
analyze -file {D:/Works/Embedded_contest/dev/pl_dma/build/td_shared/gp_control_regs.v}
analyze -file {D:/Works/Embedded_contest/dev/pl_dma/build/td_shared/gp_ps_write_adapter.v}
analyze -file {D:/Works/Embedded_contest/dev/pl_dma/build/td_shared/probe.v}
elaborate -top dma_td_probe
optimize_rtl
read_sdc dma.sdc
optimize_gate -maparea gate.area
update_timing
report_timing_summary -file gate.timing -path_num 3
check_timing -verbose -file gate.check
export_db gate.db
puts DMA_TD_COMPLETE
exit
