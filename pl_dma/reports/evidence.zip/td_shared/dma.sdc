create_clock -name dma_clk -period 10 [get_ports clk]
