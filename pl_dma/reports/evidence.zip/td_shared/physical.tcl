cd {D:/Works/Embedded_contest/dev/pl_dma/build/td_shared}
import_device dr1_90.db -package DR1M90GEG400 -speed 2
import_db gate.db
read_sdc dma.sdc
legalize_phy_inst
place
update_timing -mode manhattan
report_timing_summary -file place.timing -path_num 3
report_area -file place.area
route
update_timing -mode final
report_timing_summary -file route.timing -path_num 3
report_area -file route.area
check_timing -verbose -file route.check
report_route_status -drc
export_db route.db
puts DMA_TD_COMPLETE
exit
