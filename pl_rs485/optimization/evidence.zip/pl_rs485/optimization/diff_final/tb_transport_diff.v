`timescale 1ns/1ps
module tb_telemetry;
 reg clk=0;always #5 clk=~clk;
 reg rst_n=0,dma_ready=0,dma_quiescent=1;reg [63:0] time_us=0;
 // Accelerated externally supplied time for wrap/age/flush tests, no RTL epoch.
 always @(posedge clk) time_us<=time_us+1;
 reg event_valid=0;reg [255:0] event_raw=0;reg [31:0] generation=0,revision=2;
 reg [159:0] periods={5{32'd50000}};reg [4:0] mask=31;
 `include "telemetry_bfm.vh"
 wire diag_valid;wire [255:0] diag_data;wire [31:0] diag_level,diag_drop;
 record_fifo #(.DEPTH(8)) diagnostic(clk,rst_n && generation==0,event_valid,event_raw,1'b0,diag_valid,diag_data,diag_drop,diag_level);
 wire irq;wire [63:0] m_data;wire [7:0] m_keep;wire m_last,m_valid;reg m_ready=0;
 rs485_telem_top dut(.clk(clk),.rst_n(rst_n),.dma_ready(dma_ready),.dma_quiescent(dma_quiescent),.time_us(time_us),.event_valid(event_valid),.event_raw(event_raw),.collector_generation(generation),.event_revision(revision),.active_period_us(periods),.active_mask(mask),
 .s_awaddr(s_awaddr),.s_araddr(s_araddr),.s_wdata(s_wdata),.s_wstrb(s_wstrb),.s_awvalid(s_awvalid),.s_wvalid(s_wvalid),.s_bready(s_bready),.s_arvalid(s_arvalid),.s_rready(s_rready),.s_awready(s_awready),.s_wready(s_wready),.s_bvalid(s_bvalid),.s_arready(s_arready),.s_rvalid(s_rvalid),.s_bresp(s_bresp),.s_rresp(s_rresp),.s_rdata(s_rdata),.irq(irq),.m_data(m_data),.m_keep(m_keep),.m_last(m_last),.m_valid(m_valid),.m_ready(m_ready));
wire ref_s_awready;
wire ref_s_wready;
wire ref_s_bvalid;
wire ref_s_arready;
wire ref_s_rvalid;
wire [1:0] ref_s_bresp;
wire [1:0] ref_s_rresp;
wire [31:0] ref_s_rdata;
wire ref_irq;
wire [63:0] ref_m_data;
wire [7:0] ref_m_keep;
wire ref_m_last;
wire ref_m_valid;
 rs485_telem_top_baseline reference_transport(.clk(clk),.rst_n(rst_n),.dma_ready(dma_ready),.dma_quiescent(dma_quiescent),.time_us(time_us),.event_valid(event_valid),.event_raw(event_raw),.collector_generation(generation),.event_revision(revision),.active_period_us(periods),.active_mask(mask),
 .s_awaddr(s_awaddr),.s_araddr(s_araddr),.s_wdata(s_wdata),.s_wstrb(s_wstrb),.s_awvalid(s_awvalid),.s_wvalid(s_wvalid),.s_bready(s_bready),.s_arvalid(s_arvalid),.s_rready(s_rready),.s_awready(ref_s_awready),.s_wready(ref_s_wready),.s_bvalid(ref_s_bvalid),.s_arready(ref_s_arready),.s_rvalid(ref_s_rvalid),.s_bresp(ref_s_bresp),.s_rresp(ref_s_rresp),.s_rdata(ref_s_rdata),.irq(ref_irq),.m_data(ref_m_data),.m_keep(ref_m_keep),.m_last(ref_m_last),.m_valid(ref_m_valid),.m_ready(m_ready));
always @(negedge clk) if(rst_n) begin
 if(s_awready!==ref_s_awready) $fatal(1,"transport differential s_awready");
 if(s_wready!==ref_s_wready) $fatal(1,"transport differential s_wready");
 if(s_bvalid!==ref_s_bvalid) $fatal(1,"transport differential s_bvalid");
 if(s_arready!==ref_s_arready) $fatal(1,"transport differential s_arready");
 if(s_rvalid!==ref_s_rvalid) $fatal(1,"transport differential s_rvalid");
 if(s_bvalid && s_bresp!==ref_s_bresp) $fatal(1,"transport differential s_bresp");
 if(s_rvalid && s_rresp!==ref_s_rresp) $fatal(1,"transport differential s_rresp");
 if(s_rvalid && s_rdata!==ref_s_rdata) $fatal(1,"transport differential s_rdata");
 if(irq!==ref_irq) $fatal(1,"transport differential irq");
 if(m_valid && m_data!==ref_m_data) $fatal(1,"transport differential m_data");
 if(m_valid && m_keep!==ref_m_keep) $fatal(1,"transport differential m_keep");
 if(m_valid && m_last!==ref_m_last) $fatal(1,"transport differential m_last");
 if(m_valid!==ref_m_valid) $fatal(1,"transport differential m_valid");
 if(dut.transport.fifo_level!==reference_transport.transport.fifo_level) $fatal(1,"transport differential fifo_level");
 if(dut.transport.status!==reference_transport.transport.status) $fatal(1,"transport differential status");
 if(dut.transport.completion_serial!==reference_transport.transport.completion_serial) $fatal(1,"transport differential completion_serial");
 if(dut.transport.full_drop!==reference_transport.transport.full_drop) $fatal(1,"transport differential full_drop");
 if(dut.transport.disabled_drop!==reference_transport.transport.disabled_drop) $fatal(1,"transport differential disabled_drop");
 if(dut.transport.cancel_drop!==reference_transport.transport.cancel_drop) $fatal(1,"transport differential cancel_drop");
 if(dut.transport.stream_records!==reference_transport.transport.stream_records) $fatal(1,"transport differential stream_records");
 if(dut.transport.stream_packets!==reference_transport.transport.stream_packets) $fatal(1,"transport differential stream_packets");
 if(dut.transport.dma_ok!==reference_transport.transport.dma_ok) $fatal(1,"transport differential dma_ok");
 if(dut.transport.dma_failed!==reference_transport.transport.dma_failed) $fatal(1,"transport differential dma_failed");
 if(dut.transport.wait_arm_max_us!==reference_transport.transport.wait_arm_max_us) $fatal(1,"transport differential wait_arm_max_us");
 if(dut.transport.backpressure_max_cycles!==reference_transport.transport.backpressure_max_cycles) $fatal(1,"transport differential backpressure_max_cycles");
 if(dut.transport.ready_lateness_max_us!==reference_transport.transport.ready_lateness_max_us) $fatal(1,"transport differential ready_lateness_max_us");
 if(dut.transport.packet_id!==reference_transport.transport.packet_id) $fatal(1,"transport differential packet_id");
 if(dut.transport.packet_generation!==reference_transport.transport.packet_generation) $fatal(1,"transport differential packet_generation");
 if(dut.transport.packet_count!==reference_transport.transport.packet_count) $fatal(1,"transport differential packet_count");
 if(dut.transport.packet_bytes!==reference_transport.transport.packet_bytes) $fatal(1,"transport differential packet_bytes");
 if(dut.transport.command_error!==reference_transport.transport.command_error) $fatal(1,"transport differential command_error");
 if(dut.transport.command_result!==reference_transport.transport.command_result) $fatal(1,"transport differential command_result");
 if(dut.transport.events!==reference_transport.transport.events) $fatal(1,"transport differential events");
end


 reg collision_sent=0,collision_active=0;
 always @(negedge clk) begin
  if(collision_active) begin event_valid=0;collision_active=0;end
  else if(!collision_sent && m_valid && m_ready && dut.transport.count==256 && dut.transport.beat==7) begin
   event_raw={8'd1,8'he2,8'h39,8'd0,8'd1,8'd2,32'd999,time_us-64'd10,time_us,48'd123};
   event_valid=1;collision_active=1;collision_sent=1;
  end
 end
 initial begin wait(collision_sent);$display("PASS full FIFO simultaneous pop/push differential");end
 
 task emit;input [7:0] addr,q,status,len;input [47:0] payload;input [31:0] seq;
  begin ticks(1);event_raw={8'd1,addr,q,status,8'd1,len,seq,time_us-64'd10,time_us,payload};event_valid=1;ticks(1);event_valid=0;end
 endtask
 task snap;input [31:0] id;begin wr(`RT_REG_SNAP_REQ_ID,id,15,0);wr(`RT_REG_SNAP_SUBMIT,1,15,0);end endtask
 task recover_to;input [31:0] gen;
  begin wr(`RT_REG_RECOVER_GEN,gen,15,0);wr(`RT_REG_RECOVER,1,15,0);wr(`RT_REG_ENABLE,1,15,0);end
 endtask
 task arm_packet;input [31:0] id,gen,bytes;
  begin wr(`RT_REG_ARM_ID,id,15,0);wr(`RT_REG_ARM_GEN,gen,15,0);wr(`RT_REG_ARM_BYTES,bytes,15,0);wr(`RT_REG_ARM,1,15,0);end
 endtask
 task acknowledge;input [31:0] id,gen;
  begin wr(`RT_REG_COMPLETE_ID,id,15,0);wr(`RT_REG_COMPLETE_GEN,gen,15,0);wr(`RT_REG_COMPLETE_RESULT,0,15,0);wr(`RT_REG_COMPLETE,1,15,0);end
 endtask
 reg [511:0] frame;reg [63:0] held;reg held_last,blocked=0;integer beats=0,frames=0,packets=0;integer vectors;initial vectors=$fopen("frames.hex","w");
 reg [31:0] crc;integer j;reg [7:0] b;
 always @(posedge clk) if(rst_n && dma_ready) begin
  if(blocked && (!m_valid || m_data!==held || m_last!==held_last || m_keep!=255)) $fatal(1,"AXIS stalled stability");
  blocked=m_valid&&!m_ready;held=m_data;held_last=m_last;
  if(m_valid && m_ready) begin
   frame[beats*64+:64]=m_data;if(m_keep!=255) $fatal(1,"KEEP");
   if(beats==7) begin
    crc=32'hffffffff;
    for(j=0;j<60;j=j+1) begin b=frame[j*8+:8];crc=crc^b;repeat(8) crc=crc[0]?(crc>>1)^32'hedb88320:crc>>1;end
    if(frame[511:480]!=(crc^32'hffffffff) || frame[31:0]!=`RT_RECORD_MAGIC || frame[63:48]!=64 || frame[47:32]!=1) $fatal(1,"CRC/record format");
    if(frame[159:128]!=dut.transport.transport_generation) $fatal(1,"transport tag");
    $fdisplay(vectors,"%0128h",frame);frames=frames+1;beats=0;
   end else begin if(m_last) $fatal(1,"half record TLAST");beats=beats+1;end
   if(m_last) packets=packets+1;
  end
 end else blocked=0;
 integer n,q;reg [7:0] query,len;reg [47:0] payload;reg [31:0] v,id;
 reg step=0,ref_step=0;always @(posedge clk) begin step<=~step;ref_step<=~ref_step;end
 always @(negedge clk) if(step!==ref_step) $fatal(1,"STEP isolation");
 initial begin
  ticks(5);rst_n=1;ticks(3);dma_ready=1;ticks(3);recover_to(1);
  // All 15 slots, signed boundaries and raw unknown enum.
  for(n=0;n<3;n=n+1) for(q=0;q<5;q=q+1) begin
   case(q) 0:begin query=8'h30;len=6;payload=48'hffffffff8000;end
    1:begin query=8'h33;len=4;payload=48'h000080000000;end
    2:begin query=8'h39;len=2;payload=48'h000000008000;end
    3:begin query=8'h3a;len=1;payload=2;end
    4:begin query=8'h3e;len=1;payload=8'h80;end endcase
   emit(8'he0+n,query,0,len,payload,n*5+q);
  end
  snap(1);eq(`RT_ROW_BASE+`RT_ROW_CARRY,32'hffffffff);eq(`RT_ROW_BASE+`RT_ROW_VALUE_ENUM,32'h00008000);
  eq(`RT_ROW_BASE+`RT_ROW_STRIDE+`RT_ROW_SIGNED,32'h80000000);eq(`RT_ROW_BASE+`RT_ROW_STRIDE+`RT_ROW_SIGNED+4,32'hffffffff);
  eq(`RT_ROW_BASE+2*`RT_ROW_STRIDE+`RT_ROW_SIGNED,32'hffff8000);eq(`RT_ROW_BASE+3*`RT_ROW_STRIDE+`RT_ROW_FLAGS,15);
  eq(`RT_ROW_BASE+4*`RT_ROW_STRIDE+`RT_ROW_FLAGS,7);eq(`RT_ROW_BASE+`RT_ROW_VALID_REVISION,2);
  revision=9;emit(8'he0,8'h30,3,0,0,99);snap(2);eq(`RT_ROW_BASE+`RT_ROW_FLAGS,3);eq(`RT_ROW_BASE+`RT_ROW_CARRY,32'hffffffff);eq(`RT_ROW_BASE+`RT_ROW_VALID_REVISION,2);eq(`RT_ROW_BASE+`RT_ROW_RESULT_REVISION,9);
  // Freeze full batch, no RX credit: never assert VALID; overflow cannot stop cache.
  wait(dut.transport.state==1);rd(`RT_REG_PACKET_ID,0,id);eq(`RT_REG_PACKET_COUNT,16);
  for(n=0;n<260;n=n+1) emit(8'he1,8'h39,0,2,n,n);
  if(m_valid) $fatal(1,"sent without buffer credit");eq(`RT_REG_FIFO_LEVEL,256);eq(`RT_REG_FULL_DROP,20);
  if(diag_level!=8 || diag_drop!=268) $fatal(1,"independent diagnostic FIFO drops");
  snap(3);eq(`RT_ROW_BASE+7*`RT_ROW_STRIDE+`RT_ROW_SIGNED,259);

  wr(`RT_REG_IRQ_MASK,`RT_IRQ_PACKET_READY,15,0);wr(`RT_REG_IRQ_PENDING,31,15,0);
  rd(`RT_REG_IRQ_PENDING,0,v);if(!(v&`RT_IRQ_PACKET_READY) || !irq) $fatal(1,"persistent READY W1C set-wins");
  wr(`RT_REG_IRQ_MASK,0,15,0);if(irq) $fatal(1,"masked IRQ");
  wr(`RT_REG_IRQ_PENDING,31,15,0);rd(`RT_REG_IRQ_PENDING,0,v);if(!(v&1)) $fatal(1,"masked READY lost");
  wr(`RT_REG_IRQ_MASK,1,15,0);if(!irq) $fatal(1,"unmask pending source");wr(`RT_REG_IRQ_MASK,0,15,0);
  arm_packet(id,1,1024);wait(m_valid);ticks(30);if(!m_valid) $fatal(1,"held VALID");
  m_ready=1;wait(dut.transport.state==5);ticks(1);if(frames!=16 || packets!=1) $fatal(1,"batch");acknowledge(id,1);acknowledge(id,1);
  wr(`RT_REG_CANCEL,1,15,0);eq(`RT_REG_FIFO_LEVEL,0);recover_to(2);
  // A single record flushes without waiting for a full batch; exact short BTT.
  time_us=64'hfffffffffffffff0;emit(8'he0,8'h33,0,4,32'h7fffffff,100);time_us=64'd10020;
  wait(dut.transport.state==1);rd(`RT_REG_PACKET_ID,0,id);eq(`RT_REG_PACKET_BYTES,64);arm_packet(id,2,64);wait(dut.transport.state==5);acknowledge(id,2);
  snap(4);eq(`RT_ROW_BASE+`RT_ROW_STRIDE+`RT_ROW_SIGNED,32'h7fffffff);
  time_us=time_us+200000;snap(5);rd(`RT_ROW_BASE+`RT_ROW_STRIDE+`RT_ROW_FLAGS,0,v);if(!(v&`RT_FLAG_STALE)) $fatal(1,"stale age");
  mask=0;snap(6);rd(`RT_ROW_BASE+`RT_ROW_STRIDE+`RT_ROW_FLAGS,0,v);if(!(v&`RT_FLAG_DISABLED)) $fatal(1,"disabled");mask=31;
  // Cancel held VALID cannot retract or change payload; only primary reset fences.
  emit(8'he0,8'h3a,0,1,1,101);time_us=time_us+10010;wait(dut.transport.state==1);rd(`RT_REG_PACKET_ID,0,id);m_ready=0;arm_packet(id,2,64);wait(m_valid);wr(`RT_REG_CANCEL,1,15,0);ticks(20);if(!m_valid) $fatal(1,"cancel retracted VALID");
  dma_ready=0;ticks(3);dma_ready=1;beats=0;ticks(3);eq(`RT_REG_FIFO_LEVEL,0);wr(`RT_REG_ARM,1,15,2);
  dma_quiescent=0;wr(`RT_REG_RECOVER_GEN,3,15,0);wr(`RT_REG_RECOVER,1,15,2);dma_quiescent=1;recover_to(3);
  snap(7);rd(`RT_ROW_BASE+`RT_ROW_STRIDE+`RT_ROW_FLAGS,0,v);if(!(v&1)) $fatal(1,"DMA reset cleared cache");
  generation=1;ticks(3);snap(8);rd(`RT_ROW_BASE+`RT_ROW_STRIDE+`RT_ROW_FLAGS,0,v);if(v&3) $fatal(1,"collector reset cache valid");
  // Unknown address/query/malformed length never overwrites valid rows.
  emit(8'hf0,8'h39,0,2,5,0);emit(8'he0,8'h36,0,2,5,0);emit(8'he0,8'h30,0,5,5,0);eq(`RT_REG_PARSE_ERRORS,3);
  wr(`RT_REG_IRQ_MASK,31,15,0);wr(`RT_REG_IRQ_PENDING,31,15,0);
  rd_abs(33'h180800000,3,3,v);wr(`RT_REG_VERSION,1,15,2);wr(`RT_REG_ARM,1,1,2);

  eq(`RT_REG_DMA_FAILED,1);
  emit(8'he0,8'h3a,0,1,2,500);time_us=time_us+10010;wait(dut.transport.state==1);
  rd(`RT_REG_PACKET_ID,0,id);rd(`RT_REG_PACKET_BYTES,0,v);arm_packet(id,3,v);wait(m_valid);
  wr(`RT_REG_COMPLETE_ID,id,15,0);wr(`RT_REG_COMPLETE_GEN,3,15,0);wr(`RT_REG_COMPLETE_RESULT,1,15,0);wr(`RT_REG_COMPLETE,1,15,0);
  eq(`RT_REG_DMA_FAILED,2);ticks(10);if(!m_valid) $fatal(1,"failed completion retracted VALID");
  wr(`RT_REG_COMPLETE,1,15,0);eq(`RT_REG_DMA_FAILED,2);
  wr(`RT_REG_COMPLETE_RESULT,0,15,0);wr(`RT_REG_COMPLETE,1,15,2);
  dma_ready=0;ticks(3);dma_ready=1;ticks(3);eq(`RT_REG_DMA_FAILED,2);

  wr(`RT_REG_IRQ_MASK,`RT_IRQ_FAULT,15,0);wr(`RT_REG_IRQ_PENDING,31,15,0);eq(`RT_REG_IRQ_PENDING,0);
  fork
   wr(`RT_REG_IRQ_PENDING,`RT_IRQ_FAULT,15,0);
   begin wait(dut.regs.wf && dut.regs.wa[11:0]==`RT_REG_IRQ_PENDING);dma_ready=0;end
  join
  ticks(3);eq(`RT_REG_IRQ_PENDING,`RT_IRQ_FAULT);if(!irq) $fatal(1,"edge fault lost to W1C");
  wr(`RT_REG_IRQ_PENDING,`RT_IRQ_FAULT,15,0);if(irq) $fatal(1,"fault source cleared");
  wr(`RT_REG_IRQ_MASK,0,15,0);dma_ready=1;ticks(3);dma_ready=0;ticks(3);
  eq(`RT_REG_IRQ_PENDING,`RT_IRQ_FAULT);if(irq) $fatal(1,"masked edge fault");
  wr(`RT_REG_IRQ_MASK,`RT_IRQ_FAULT,15,0);if(!irq) $fatal(1,"edge rearm");
  wr(`RT_REG_IRQ_PENDING,`RT_IRQ_FAULT,15,0);if(irq) $fatal(1,"edge W1C");

  // Repeated snapshot ID must replay its frozen time/data, then a new ID sees
  // the updates. The cache differential also checks all row words directly.
  rd(`RT_SNAPSHOT_BASE,0,v);held={32'd0,v};time_us=time_us+64'd123456;
  emit(8'he0,8'h30,0,6,48'h80000000ffff,900);snap(8);eq(`RT_SNAPSHOT_BASE,held[31:0]);
  snap(9);rd(`RT_SNAPSHOT_BASE,0,v);if(v==held[31:0]) $fatal(1,"new snapshot did not recapture");
  dma_ready=1;ticks(3);recover_to(4);beats=0;m_ready=0;
  for(n=0;n<256;n=n+1) emit(8'he1,8'h33,0,4,n,n);
  eq(`RT_REG_FIFO_LEVEL,256);time_us=time_us+10010;
  for(q=0;q<20;q=q+1) begin
   wait(dut.transport.state==1);rd(`RT_REG_PACKET_ID,0,id);arm_packet(id,4,1024);
   wait(m_valid);ticks(200);m_ready=1;wait(dut.transport.state==5);ticks(1);acknowledge(id,4);m_ready=0;
   if(q<4) for(n=0;n<16;n=n+1) emit(8'he2,8'h30,0,6,{16'd0,q[15:0],n[15:0]},32'd2000+n);
  end
  eq(`RT_REG_FIFO_LEVEL,0);
  emit(8'he0,8'h3e,0,1,1,3000);time_us=time_us+10010;wait(dut.transport.state==1);
  rd(`RT_REG_PACKET_ID,0,id);arm_packet(id,4,64);wait(m_valid);ticks(2000);m_ready=1;
  wait(dut.transport.state==5);ticks(1);acknowledge(id,4);eq(`RT_REG_FIFO_LEVEL,0);
  $display("PASS ERAM ring wrap and one-record refresh/long backpressure differential");
   $display("PASS telemetry unit checks=%0d frames=%0d packets=%0d parser/cache/drop/CRC/credit/cancel/wrap",checks,frames,packets);$finish;
 end
 initial begin #5000000;$fatal(1,"telemetry unit watchdog");end
endmodule
